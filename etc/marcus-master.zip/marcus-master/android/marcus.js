var jQT = $.jQTouch({
    icon: 'kilo.png'
});

